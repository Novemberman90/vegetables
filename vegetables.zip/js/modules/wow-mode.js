import WOW from '../../node_modules/wow.js/src/WOW.js';

 export const initWow = () => {
   new WOW().init();
};
