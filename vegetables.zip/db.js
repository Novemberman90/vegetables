 export const data = {
  cards: [
    {
      "img": "./images/product/product1.webp",
      "altimg": "vegetables",
      "title": "Carrot",
      "descr": "Plant",
      "price": 100,
      "id": ""
    },
    {
      "img": "./images/product/product2.webp",
      "altimg": "vegetables",
      "title": "Brussel sprouts",
      "descr": "Plant",
      "price": 80,
      "id": ""
    },
    {
      "img": "./images/product/product3.webp",
      "altimg": "vegetables",
      "title": "Tomato",
      "descr": "Plant",
      "price": 40,
      "id": ""
    },
    {
      "img": "./images/product/product4.webp",
      "altimg": "vegetables",
      "title": "Eggplant",
      "descr": "Plant",
      "price": 60,
      "id": ""
    },
    {
      "img": "./images/product/product5.webp",
      "altimg": "vegetables",
      "title": "Sweet potatoes",
      "descr": "Plant",
      "price": 80,
      "id": ""
    },
    {
      "img": "./images/product/product6.webp",
      "altimg": "vegetables",
      "title": "Leek",
      "descr": "Plant",
      "price": 50,
      "id": ""
    },
    {
      "img": "./images/product/product7.webp",
      "altimg": "vegetables",
      "title": "Mushrooms",
      "descr": "Plant",
      "price": 40,
      "id": ""
    },
    {
      "img": "./images/product/product8.webp",
      "altimg": "vegetables",
      "title": "Corn",
      "descr": "Plant",
      "price": 60,
      "id": ""
    },
    {
      "img": "./images/product/product9.webp",
      "altimg": "vegetables",
      "title": "Radish",
      "descr": "Plant",
      "price": 90,
      "id": ""
    },
  ]
}
